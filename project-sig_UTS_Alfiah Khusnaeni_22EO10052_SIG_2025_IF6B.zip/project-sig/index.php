<?php
// Include database connection
include 'db_connection.php';

// Fetch data for health services
$sql = "SELECT id, name, latitude, longitude FROM health_services";
$result = $conn->query($sql);

// Collect health services data into an array
$health_services = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $health_services[] = $row;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Peta Kecamatan dan Layanan Kesehatan Banyumas</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
        integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
        integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>

    <style>
    #map {
        height: 600px;
    }

    #controls {
        margin: 10px 0;
    }
    </style>
</head>

<body>

    <h1>Peta Kecamatan dan Layanan Kesehatan Kabupaten Banyumas</h1>
    <a href="crud.php" target="_blank">
        <button>Data</button>
    </a>

    <div id="controls">
        <label for="loc1">Pilih Fasilitas 1:</label>
        <select id="loc1">
            <?php foreach ($health_services as $service): ?>
            <option value="<?= $service['latitude'] . ',' . $service['longitude'] ?>">
                <?= htmlspecialchars($service['name']) ?>
            </option>
            <?php endforeach; ?>
        </select>

        <label for="loc2">Pilih Fasilitas 2:</label>
        <select id="loc2">
            <?php foreach ($health_services as $service): ?>
            <option value="<?= $service['latitude'] . ',' . $service['longitude'] ?>">
                <?= htmlspecialchars($service['name']) ?>
            </option>
            <?php endforeach; ?>
        </select>

        <button onclick="calculateDistance()">Hitung Jarak</button>
        <p id="distance-result"></p>
    </div>

    <div id="map"></div>

    <script type="text/javascript" src="data/kecamatan.json"></script>

    <script>
    // Inisialisasi peta
    const map = L.map('map').setView([-7.4501619925610265, 109.16218062235065], 11);

    // Tile layer
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    }).addTo(map);

    // Tampilkan batas kecamatan
    L.geoJSON(kecamatan, {
        style: function(feature) {
            return {
                color: 'blue',
                weight: 2
            };
        }
    }).addTo(map);

    // Data marker dari PHP
    const healthServices = <?php echo json_encode($health_services); ?>;
    healthServices.forEach(service => {
        L.marker([service.latitude, service.longitude]).addTo(map)
            .bindPopup('<b>' + service.name + '</b>');
    });

    // Konversi derajat ke radian
    function toRad(deg) {
        return deg * Math.PI / 180;
    }

    // Algoritma Haversine
    function haversine(lat1, lon1, lat2, lon2) {
        const R = 6371;
        const dLat = toRad(lat2 - lat1);
        const dLon = toRad(lon2 - lon1);
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }

    let currentLine = null; // Untuk menyimpan garis saat ini

    function calculateDistance() {
        const loc1 = document.getElementById('loc1').value.split(',');
        const loc2 = document.getElementById('loc2').value.split(',');

        const lat1 = parseFloat(loc1[0]);
        const lon1 = parseFloat(loc1[1]);
        const lat2 = parseFloat(loc2[0]);
        const lon2 = parseFloat(loc2[1]);

        // Hitung jarak
        const distance = haversine(lat1, lon1, lat2, lon2);
        document.getElementById('distance-result').innerHTML =
            `<b>Jarak:</b> ${distance.toFixed(2)} km`;

        // Hapus garis sebelumnya jika ada
        if (currentLine) {
            map.removeLayer(currentLine);
        }

        // Buat garis antar dua titik
        currentLine = L.polyline([
            [lat1, lon1],
            [lat2, lon2]
        ], {
            color: 'red',
            weight: 3,
            dashArray: '5, 10'
        }).addTo(map);

        // Zoom ke area garis
        map.fitBounds(currentLine.getBounds());
    }
    </script>

</body>

</html>